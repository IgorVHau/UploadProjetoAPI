package org.serratec.ecomerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
