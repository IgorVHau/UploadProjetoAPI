package org.serratec.ecommerce.exception;

public class PedidoNaoExisteException extends Exception {
	
	public PedidoNaoExisteException(String message) {
		super(message);
	}

}
