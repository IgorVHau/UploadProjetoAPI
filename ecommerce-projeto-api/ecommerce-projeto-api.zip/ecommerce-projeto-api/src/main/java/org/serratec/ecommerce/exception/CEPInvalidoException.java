package org.serratec.ecommerce.exception;

public class CEPInvalidoException extends Exception {
	
	
	public CEPInvalidoException(String message) {
		super(message);
	}
}
